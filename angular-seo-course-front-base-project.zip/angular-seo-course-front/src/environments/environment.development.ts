export const environment = {
  frontUrl: "http://localhost:4200",
  apiUrl: "http://localhost:3000"
}
