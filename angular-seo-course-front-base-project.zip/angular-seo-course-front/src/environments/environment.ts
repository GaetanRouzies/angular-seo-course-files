export const environment = {
  frontUrl: "TO_CHANGE",
  apiUrl: "TO_CHANGE"
}
