export const envFilePath =
  process.env.NODE_ENV == 'production' ? '.env' : '.development.env';
